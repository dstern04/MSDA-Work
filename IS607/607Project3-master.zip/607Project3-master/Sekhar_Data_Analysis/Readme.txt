Adding my data analysis work. 
As per my analysis (using Bayes theorem), Direction category is the best predictor, followed by Editing. See the detailed analysis at http://www.rpubs.com/msekhar12/68495


Let me know if you have any questions.

Thanks,
Sekhar